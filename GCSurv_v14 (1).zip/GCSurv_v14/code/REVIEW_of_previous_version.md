# Strict review of the previous GCSurv manuscript (Elsevier version), code v13 and results archive

Verdict: reject in its previous form, at any venue. Rewording alone could not fix the problems below.
Most are fixed in v14 and in the rewritten paper. The remaining ones are listed under "Still open".

## A. Fatal problems

1. **The headline model was tuned on the test set.** `train_optimized_svm()` picks `alpha` and `kernel`
   with `ssvm.score(X_test, y_test) - 0.5*|train - test|`. The claims "Survival SVM achieves the highest
   held-out C-index (0.7362)" and "No test-set information was used for model selection" are therefore
   false.
2. **Feature selection used test patients.** `stability_feature_selection()` runs on `X_all, y_all`
   (all 1,879 patients) before the split. It also uses `mutual_info_regression` on the time column alone,
   which ignores censoring. The Combined, RSF and GBS feature sets depend on it.
3. **Biased univariate ranking.** The univariate Cox loop keeps only `Time > 0`. Because time had been
   standardised, this drops roughly half the training patients and keeps the ones with longer follow-up.
   The ablation ranking, the SVM's top-20 features and the significant-feature set all come from this
   ranking.
4. **"Leakage-aware" was the wrong concept.** Tumour type is a legitimate baseline variable, so including
   it is not leakage. Excluding it does not remove the shortcut either: sex is close to a BRCA flag,
   AJCC sub-stage coding differs by cancer, and APC/KRAS/PIK3CA track tumour type. The pooled C-index
   mixes between-cancer and within-cancer ranking, and the paper never separated them.
5. **Survival time was not in years.** The input CSV has standardised time (range -2.18 to 1.87, with
   negative values). The text says "years" and "zero times replaced with 0.001", and the KM x-axis is
   labelled in years. None of these is true. Rank statistics (C-index, log-rank) survive a monotone
   transform; the descriptions do not.

## B. Major problems

6. **The gene panel is mostly passenger genes.** TTN, MUC16, CSMD3, RYR2, LRP1B, USH2A, SYNE1, FLG,
   MUC17, XIRP2 and ZFHX4 are long genes that are frequently mutated because of their length and
   replication timing (Lawrence et al., 2013). Citing Bailey et al. (2018) and Kandoth et al. (2013) as
   the source of this panel misrepresents those papers. MUC16 as the "strongest genomic predictor" most
   likely reflects tumour mutational burden.
7. **Inference did not support the claims.** Overlapping bootstrap CIs were read as "comparable".
   A paired bootstrap on the saved test-set risk scores (n = 564, 2,000 resamples) gives:
   - SVM vs clinical Cox: dC = +0.005, 95% CI [-0.020, +0.030], p = 0.69.
   - Genomic-only vs clinical Cox: dC = -0.056, 95% CI [-0.116, +0.006], p = 0.07.

   So even "clinical dominates genomic" was not established on that test set.
8. **The ablation maximum was optimistic.** The "0.7666 at 30 features" value is the maximum over seven
   models on the test set for each feature count. In the ablation CSV, the Cox Clinical, Genomic and
   Combined rows are identical for the top-k sets because they were fitted on the same features under
   different labels.
9. **The code and the results didn't match.** The archive has a 70/30 split; v13 has train/val/test.
   Forest settings differ three ways (paper: 100/10/5; code: 200/20/10 and 500/50/25). `results.json`,
   `part3_checkpoint.npz` and three of the logs belong to unrelated projects (CIFAR, DCLED/Llama-3.2).
10. **A post-baseline variable was used as a baseline covariate.** TCGA's
    `received_pharmaceutical_treatment` is recorded after diagnosis.
11. **Risk-group tertiles: text and code disagreed.** The text says the tertiles were cut on the test
    set; the code used training cut-offs. Pooled tertiles also sort patients by cancer type, and the
    paper did not discuss this.
12. **Evaluation was too thin.** There was only Harrell's C on one split: no Uno's C, time-dependent
    AUC, Brier score or calibration, and no stratified or within-cancer analysis.

## C. Fit to the target venue

13. The paper has no language component. NAACL/ACL reviewers would rate it out of scope. The rewrite
    uses the ACL template as you asked, but the content is positioned for a clinical-ML or
    bioinformatics venue.

## D. Fixed in v14 and the rewritten paper

Nested repeated CV (5x5 outer folds, 3-fold inner tuning); within- and between-cancer decomposition of
C; Uno's C, td-AUC and IBS; paired Nadeau-Bengio tests; frequency vs driver panel vs TMB, with
TMB-adjusted gene HRs; leave-one-cancer-out transfer; progression-free-interval sensitivity analysis;
training-fold risk tertiles, pooled and within cancer; an optimism audit that measures E1-E3 against
an untouched hold-out; time in years from the TCGA-CDR; public, reproducible data (cBioPortal
PanCancer Atlas).

## E. Still open (cannot be fixed without new data)

- No external cohort (for example CPTAC, or GENIE-BPC with clinical outcomes) has been added.
- Mutation representation is still binary gene-level flags.
- The text needs a final consistency pass once the full v14 results exist (gene-dependent sentences).
